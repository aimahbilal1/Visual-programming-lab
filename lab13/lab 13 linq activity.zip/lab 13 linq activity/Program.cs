﻿using System;
using System.Collections.Generic; // Required for List<T>
using System.Linq;

namespace lab_13_linq_activity
{
    public class StudentClass
    {
        public enum GradeLevel { FirstYear = 1, SecondYear, ThirdYear, FourthYear }

        public class Student
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int ID { get; set; }
            public GradeLevel Year { get; set; }
            public List<int> ExamScores { get; set; }
            public double AverageScore { get; set; }

            // Constructor to initialize Student
            public Student(string firstName, string lastName, int id, GradeLevel year, List<int> examScores)
            {
                FirstName = firstName;
                LastName = lastName;
                ID = id;
                Year = year;
                ExamScores = examScores;
                AverageScore = 0; // Initialize average score
            }
        }

        public static List<Student> students = new List<Student>()
        {
            new Student("Terry", "Adams", 120, GradeLevel.SecondYear, new List<int> { 99, 82, 81, 79 }),
            new Student("Padi", "Fakhouri", 121, GradeLevel.ThirdYear, new List<int> { 99, 86, 90, 94 }),
            new Student("Hanying", "Liang", 122, GradeLevel.FirstYear, new List<int> { 93, 92, 80, 94 }),
            new Student("Cesar", "Hernandez", 123, GradeLevel.FourthYear, new List<int> { 97, 89, 85, 89 }),
            new Student("Debra", "James", 124, GradeLevel.ThirdYear, new List<int> { 95, 72, 77, 80 }),
            new Student("Hugo", "K", 125, GradeLevel.SecondYear, new List<int> { 92, 90, 89, 92 }),
            new Student("Sven", "Smith", 126, GradeLevel.FirstYear, new List<int> { 98, 94, 96, 90 }),
            new Student("Jason", "Williams", 127, GradeLevel.ThirdYear, new List<int> { 99, 88, 91, 90 }),
            new Student("Lara", "Johnson", 128, GradeLevel.FourthYear, new List<int> { 90, 91, 92, 93 }),
            new Student("John", "Doe", 129, GradeLevel.SecondYear, new List<int> { 88, 87, 85, 90 }),
            new Student("Alice", "Brown", 130, GradeLevel.FirstYear, new List<int> { 78, 82, 80, 75 }),
            new Student("Bob", "White", 131, GradeLevel.ThirdYear, new List<int> { 85, 84, 88, 90 }),
            new Student("Charlie", "Green", 132, GradeLevel.FourthYear, new List<int> { 95, 96, 94, 97 })
        };
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            // Calculate the average score for each student
            foreach (var student in StudentClass.students)
            {
                student.AverageScore = GetAverageScore(student.ExamScores);
            }

            // Find the high scores for each exam
            for (int examIndex = 0; examIndex < StudentClass.students[0].ExamScores.Count; examIndex++)
            {
                Console.WriteLine($"High scores for exam {examIndex + 1}:");
                GetHighScores(StudentClass.students, examIndex);
            }

            // Find the percentile for each student
            foreach (var student in StudentClass.students)
            {
                Console.WriteLine($"{student.FirstName} {student.LastName}: {GetPercentile(StudentClass.students, student.AverageScore)} percentile");
            }

            Console.ReadLine(); // Prevent console from closing immediately
        }

        // Helper method to calculate the average score
        private static double GetAverageScore(List<int> scores)
        {
            if (scores.Count == 0)
            {
                return 0;
            }

            return (double)scores.Sum() / scores.Count;
        }

        // Helper method to find the high scores for each exam
        private static void GetHighScores(List<StudentClass.Student> students, int examIndex)
        {
            // Sort the students by exam score in descending order
            var sortedStudents = students.OrderByDescending(s => s.ExamScores[examIndex]).ToList();

            // Get the top 3 scores
            for (int i = 0; i < 3 && i < sortedStudents.Count; i++)
            {
                Console.WriteLine($"{sortedStudents[i].FirstName} {sortedStudents[i].LastName}: {sortedStudents[i].ExamScores[examIndex]}");
            }
        }

        // Helper method to calculate the percentile
        private static double GetPercentile(List<StudentClass.Student> students, double score)
        {
            int count = students.Count(s => s.AverageScore < score);
            return (double)count / students.Count * 100;
        }
    }
}