﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media.Animation;

namespace lab_13_233533
{
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();
            StartTimer();
        }

        private void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1); // Update every second
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            DateTime currentTime = DateTime.Now; // Get the current time
            UpdateTimeDisplay(currentTime); // Update the display
            Vibrate(); // Simulate vibration effect
        }

        private void UpdateTimeDisplay(DateTime time)
        {
            TimeDisplay.Text = time.ToString("hh:mm:ss tt"); // Update the TextBlock with the current time
        }

        private void Vibrate()
        {
            // Create a simple animation to simulate vibration
            var animation = new DoubleAnimation
            {
                From = 0,
                To = 5, // Increased amplitude for more noticeable vibration
                Duration = TimeSpan.FromMilliseconds(100), // Increased duration for longer effect
                AutoReverse = true,
                RepeatBehavior = new RepeatBehavior(5) // Repeat 5 times for better visibility
            };

            // Apply the animation to the window's left position
            this.BeginAnimation(Window.LeftProperty, animation);
        }
    }
}